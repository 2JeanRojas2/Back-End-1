package com.dh.clase23.integral;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IntegralApplicationTests {

	@Test
	void contextLoads() {
	}

}
