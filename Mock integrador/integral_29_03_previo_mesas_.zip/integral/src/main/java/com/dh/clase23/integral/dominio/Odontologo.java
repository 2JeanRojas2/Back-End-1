package com.dh.clase23.integral.dominio;

public class Odontologo {
}
